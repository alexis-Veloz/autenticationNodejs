module.exports = {
	plugins: [
		require('autoprefixer')({ /* ...options */ })
	]
};